/// Simple 'Hello, world' program
/**
 * This program prints "Hello, world" to the LCD screen
 * @author Chad Nelson
 * @date 06/26/2012
 *
 * updated: phjones 9/3/2019
 * Describtion: Added timer_init call, and including Timer.h
 */

#include "Timer.h"
#include "lcd.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "scroll.h"

#define LINE_LEN 20


int main (void) {

	timer_init(); // Initialize Timer, needed before any LCD screen fucntions can be called 
	              // and enables time functions (e.g. timer_waitMillis)

	lcd_init();   // Initialize the the LCD screen.  This also clears the screen. 

	// Clear the LCD screen and print "Hello, world" on the LCD
	// lcd_printf("Hello, world");
	// lcd_puts("Hello, worldfbwfhbweaYUGH FWYUKIYUWFGYKFEgwfyukEQ");

	// lcd_puts("Hello, world");// Replace lcd_printf with lcd_puts
                                 // step through in debug mode
                                 // and explain to TA how it
                                 // works

	int scroll_index = 0;
	int i = 0;
	const char* message = "                    Microcontrollers are lots of fun, lot of fun in 288!";
	const int len = strlen(message);
	// const char* real = malloc(sizeof(char) * (len + 20))
	// strcpy(message, real);


	while (true) {
	    lcd_clear();

	    for (i = 0; i < LINE_LEN; i++) {
	        if (message[i + scroll_index] == '\0') {
	            break;
	        }
	        lcd_putc(message[i + scroll_index]);
	    }

	    /*
	    for (i = scroll_index; i < scroll_index + LINE_LEN && message[i] != '\0'; i++) {

	        lcd_putc(message[i]);
	    }
	    */

	    timer_waitMicros(300000);

	    if (++scroll_index >= len) {
	        scroll_index = 0;
	    }
	}



    
	// NOTE: It is recommended that you use only lcd_init(), lcd_printf(), lcd_putc, and lcd_puts from lcd.h.
    // NOTE: For time fuctions see Timer.h

	return 0;
}
